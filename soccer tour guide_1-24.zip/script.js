let currentSlide = 0;

function showSlide(index) {
    const slides = document.querySelector('.slides');
    const totalSlides = document.querySelectorAll('.slide').length;
    if (index >= totalSlides) {
        currentSlide = 0;
    } else if (index < 0) {
        currentSlide = totalSlides - 1; // 3개씩 이동하므로 -3
    } else {
        currentSlide = index;
    }

    const offset = -currentSlide * (100 / 3); // 3개씩 보여주므로 100을 3으로 나눔
    slides.style.transform = `translateX(${offset}%)`;
}

function prevSlide() {
    showSlide(currentSlide - 1); // 3개씩 이동
}

function nextSlide() {
    showSlide(currentSlide + 1); // 3개씩 이동
}

// 자동 슬라이드 기능 추가 (3초마다 다음 슬라이드로 이동)
setInterval(() => {
    nextSlide();
}, 3000);

